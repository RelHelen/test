const products = [
  {
    id: "1",
    title: "Картина Осень",
    // 'src': '1.jpg',
    price: "235 р.",
    img: "1.jpg",
  },
  {
    id: "2",
    title: "Картина Лето",
    // 'src': '2.jpg',
    price: "356 р.",
    img: "2.jpg",
  },
  {
    id: "3",
    title: "Картина Зима",
    // 'src': 'img/3.jpg',
    price: "574 р.",
    img: "3.jpg",
  },
  {
    id: "4",
    title: "Картина Весна",
    // 'src': '4.jpg',
    price: "456 р.",
    img: "4.jpg",
  },
];
// export default products;
// let cart = {};//моя корзина

const productsHTML = products.map((item, index) => {
  let htmlProduct = `<section>
            <img width="800" height="500" src="./img/${item.img}" alt="${item.title}" /> 
            <h3 class = "item">${item.title}</h3>
            <p><strong>${item.price}</strong></p>
            <button class = "plus" data-id= "${item.id}"> Добавить в корзину </button>
            
        </section>`;
  if (index !== products.length - 1) htmlProduct += "<hr>";

  return htmlProduct;
});

document.body.insertAdjacentHTML("beforeend", productsHTML.join(""));

// Добавление товара в корзину и формирование массива заказов
let order = [];
let miniCart = document.querySelector("#mini-cart");

let buttons = document.querySelectorAll(".plus");
buttons.forEach((elem, i) => {
  elem.addEventListener("click", function () {
    let orderItem = document.createElement("li");
    orderItem.textContent = `${products[i].price} р.${products[i].title}`;
    order.push(products[i].title);
    miniCart.append(orderItem);
  });
});

// document.onclick = event => {
//     // console.log(event.target.classList);
//     if (event.target.classList.contains('plus')) {

//         console.log(event.target.dataset.id);
//         plusFunction(event.target.dataset.id);
//     }

// }
// const plusFunction = id => {
//     products[id]++;
//     renderProducts();

// }

// const renderProducts = () => {

//     console.log(products);
// }
// renderProducts();

// //Найти все объекты (.item)
// const itemAll = document.querySelectorAll('.item');
// // //При клике на (.item) добавлять класс “add”. При повторном клике удалять класс с этого объекта
// for (let item of itemAll) {
//     item.addEventListener('click', function(e) {
//         e.target.classList.toggle('add');
//         //             //Найти все объекты const wishList с классом “add”
//         const wishList = document.querySelectorAll('.add');
//         //             //Сформировать массив const arrList из объектов const addList, у которых класс “add”
//         const arrList = [];
//         for (let elem of wishList) {
//             const addList = {
//                 id: elem.getAttribute('id'),
//                 text: elem.textContent
//             };
//             arrList.push(addList);
//         }
//         console.log(arrList); //все избранные объекты
//         let strArrList = JSON.stringify(arrList); //в json формат
//         localStorage.setItem("wishlist", strArrList); //положили на хранилище
//     })

//     const wishlistDisplay = document.getElementById('wishlistDisplay');
//     wishlistDisplay.addEventListener('click', function() {
//         wishlistBox.innerHTML = '';
//         let list = localStorage.getItem("wishlist"); //взяли из хранилища
//         list = JSON.parse(list); //преобразовали обратно в объект
//         //перебор по  избранному list
//         list.forEach(element => {
//             console.log(element);
//             wishlistBox.innerHTML += `<li> ${element['text']} </li>`;
//         });

//     })
// }

// //вывод корзины
//('button.plus').on('click', addPlus);
// function addPlus(){
//     //добавлен товар
//     let articul = $(this).attr('data-id');
// cart[ articul] = 1;
// console.log(cart);

var count = 1, userNumber, randowNumber;

start();
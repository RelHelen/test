var count = 1, userNumber, randNumber, minNum, maxNum;

minNum = 1000;
maxNum = 9999;

start();